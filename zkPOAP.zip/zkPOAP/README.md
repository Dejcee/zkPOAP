# zkPOAP – Compressed Proof-of-Attendance Tokens on Solana

zkPOAP is a scalable Proof-of-Attendance system built on Solana using **ZK Compression** and **Solana Pay**. It lets event organizers mint and distribute compressed NFTs (cTokens) via QR codes — reducing costs while keeping security and composability.

![Architecture Diagram](./assets/zkpoap_flow.png)

---

## Features

- Mint **compressed NFTs** for event attendees
- Generate **Solana Pay QR codes** for seamless claiming
- Use **Merkle tree compression** to scale to thousands of tokens
- Built on Solana L1 using Helius + Light Protocol

---

## Tech Stack

- Solana L1  
- Helius ZK Compression API  
- Light Protocol  
- Solana Pay  
- React + Vite  
- Metaplex Metadata Standard  
- IPFS / Arweave (for NFT metadata)

---

## How It Works

1. Organizer logs in and mints a compressed NFT (cToken)
2. A Solana Pay QR is generated for the event
3. Attendees scan the QR code to claim the cToken
4. The compressed token is transferred on-chain to the wallet

---

## Live Demo

[Live Demo Link] *(if hosted)*  
[Video Demo](https://your-video-link.com) *(demo walkthrough)*

---

## Getting Started

```bash
git clone https://github.com/your-username/zkPOAP.git
cd zkPOAP
npm install
npm run dev
```

Update your `.env` file:

```
VITE_RPC_URL=https://devnet.helius-rpc.com/?api-key=YOUR_API_KEY
VITE_WALLET_ADDRESS=YOUR_WALLET
```

---

## Project Architecture

- `/src/frontend` – React-based UI with QR scan and claim flow
- `/src/backend` – Express or serverless API for mint + verification
- `/smart-contract` – Solana minting logic using Helius API or Anchor
- `/assets` – Flowcharts, wireframes, logos

---

## Submission Info

- **Hackathon**: ZK Compression Hackathon by Solana, Helius & Light Protocol
- **Track**: Best cToken Integration for Solana Pay
- **Team**: [Your Name(s)]

---

## License

MIT © 2025 zkPOAP
